from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from .views import AddToCartView
from .views import AddToCartsView

app_name = 'goods'

urlpatterns = [
                  path('', views.home, name='home'),
                  path('create/', views.create_record, name='create'),
                  path('<int:record_id>/', views.goods_detail, name='detail'),
                  path('<int:pk>/', views.goods_detail1, name='detail1'),
                  path('<int:record_id>/update/', views.update_record, name='update'),
                  path('<int:record_id>/delete/', views.delete_record, name='delete'),
                  path('list/', views.GoodsListView.as_view(), name='goods_list'),
                  path('<int:pk>/add_to_cart/', AddToCartView.as_view(), name='add_to_cart'),
                  path('add_to_carts/', AddToCartsView.as_view(), name='add_to_carts'),
                  path('sale/', views.salepage, name='sale_page'),

              ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
