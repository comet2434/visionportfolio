from django import forms
from .models import Goods

class GoodsForm(forms.ModelForm):
    class Meta:
        model = Goods
        fields = ['gid', 'gname', 'ginfo', 'price', 'amount', 'category', 'gimage']
        exclude = ['user']  # user 필드는 로그인한 사용자로부터 자동적으로 가져와서 처리


    def clean(self):
        cleaned_data = super().clean()
        price = cleaned_data.get('price')
        amount = cleaned_data.get('amount')