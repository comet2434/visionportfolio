from django.contrib.auth.models import User
from django.db import models
from users.models import CustomUser


class Goods(models.Model):
    gid = models.CharField(max_length=100, unique=True)
    gname = models.CharField(max_length=50)
    ginfo = models.CharField(max_length=3000)
    price = models.PositiveIntegerField()
    amount = models.PositiveIntegerField()
    category = models.CharField(max_length=100)
    gimage = models.ImageField(upload_to='goods_images/')  # upload_to 설정 필수
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='goods')

    class Meta:
        db_table = 'goods'

    # def __str__(self):  # 객체 표현 양식
    #     return f'{self.gid}, \{self.gname},\t{self.ginfo},\t{self.price},\t{self.amount},\t{self.category} ({self.user.username})'

    def __str__(self):  # 객체 표현 양식
        return f'{self.gid}, {self.gname}, {self.gimage.url}, {self.user.username}'

