from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static

app_name = 'ohistory'

urlpatterns = [
    path('', views.home, name='home'),
    path('create/', views.create_record, name='create'),
    path('<int:record_id>/', views.detail, name='detail'),
    path('<int:record_id>/update/', views.update_record, name='update'),
    path('<int:record_id>/delete/', views.delete_record, name='delete'),
]
