from django import forms
from .models import Ohistory

class OhistoryForm(forms.ModelForm):
    class Meta:
        model = Ohistory
        fields = ['gid', 'gname', 'mid', 'mname', 'price', 'amount', 'date']
        exclude = ['user']  # user 필드는 로그인한 사용자로부터 자동적으로 가져와서 처리

    def __init__(self, *args, **kwargs):
        user = kwargs.pop('user', None)
        super(OhistoryForm, self).__init__(*args, **kwargs)
        if user:
            self.fields['mname'].initial = user.username
            self.fields['mid'].initial = user.id

    def clean(self):
        cleaned_data = super().clean()
        price = cleaned_data.get('price')
        amount = cleaned_data.get('amount')