from django.shortcuts import render, get_object_or_404, \
    redirect  # get_object_or_404 ~ 데이터베이스에서 객체를 가져오거나 객체가 없는 경우 404오류를 반환
from django.contrib.auth.decorators import login_required
from .models import Ohistory
from .forms import OhistoryForm

@login_required
def home(request):
    records = Ohistory.objects.filter(user=request.user)
    context = {'records': records}
    return render(request, 'ohistory/home.html', context)


@login_required
def create_record(request):
    if request.method == 'POST':
        form = OhistoryForm(request.POST, request.FILES)  # 폼 데이터를 바탕으로 새로운 기록을 생성
        if form.is_valid():  # 폼이 유효하면
            record = form.save(commit=False)  # 새로운 기록 생성
            record.user = request.user
            record.save()  # 디비 저장 완료
            return redirect('ohistory:detail', record_id=record.id)
    else:
        form = OhistoryForm()  # 빈 폼을 만들고

    context = {'form': form}
    return render(request, 'ohistory/create.html', context)


@login_required
def detail(request, record_id):
    record = get_object_or_404(Ohistory, id=record_id, user=request.user)
    # 기록을 context에 저장하고 이를 detail.html 템플릿에 전달
    context = {'record': record}
    return render(request, 'ohistory/detail.html', context)


@login_required
def update_record(request, record_id):
    record = get_object_or_404(Ohistory, id=record_id, user=request.user)
    if request.method == 'POST':
        form = OhistoryForm(request.POST, instance=record)
        if form.is_valid():
            print('조건문1 통과')
            form.save()  # 디비 저장 완료
            print('조건문2 통과')
            return redirect('ohistory:detail', record_id=record.id)
        else:
            print('조건문3 통과', form.errors)
    else:
        form = OhistoryForm(instance=record)  # 기록의 현재 데이터를 가진 폼을 만들고

    context = {'form': form}
    return render(request, 'ohistory/update.html', context)


@login_required
def delete_record(request, record_id):
    record = get_object_or_404(Ohistory, id=record_id, user=request.user)
    if request.method == 'POST':
        record.delete()
        return redirect('ohistory:home')

    context = {'record': record}
    return render(request, 'ohistory/delete.html', context)
