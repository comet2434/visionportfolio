from django.shortcuts import render
from django.views.generic import ListView,DetailView
from bookmark.models import Bookmark

# Create your views here.
class BookmarkLV(ListView): # 북마크 리스트
    model = Bookmark
    #template_name = 'bookmark_list.html' # 사용할 템플릿 경로

class BookmarkDV(DetailView): # 북마크 상세
    model = Bookmark
    #template_name = 'bookmark_detail.html' # 사용할 템플릿 경로
