from django.contrib import admin
from .models import Bookmark

# Register your models here.
@admin.register(Bookmark) # 데코레이션으로 자바에서 어나테이션
class BookmarkAdmin(admin.ModelAdmin):
    list_display = ('id','title', 'url')

# 위 @admin.register(Bookmark) 대신
# admin.site.register(Bookmark, BookmarkAdmin)
# 당연히 테이블이 새로 추가된다면 models.py와 admin.py를 동시에 수정해야 함
