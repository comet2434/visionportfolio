from django.urls import path
from .views import BookmarkLV, BookmarkDV  # 앱의 views.py 파일에서 뷰 import


# 네임스페이스 정의
app_name = 'bookmark'

urlpatterns = [
    path('', BookmarkLV.as_view(), name='index'),
    # path("", BookmarkLV.as_view(), name="bookmark_list"),
    path('<int:pk>/', BookmarkDV.as_view(), name='detail'),
    # path("<int:pk>", BookmarkDV.as_view(), name="bookmark_detail")
]
