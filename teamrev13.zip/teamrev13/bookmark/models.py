from django.db import models

# Create your models here.
class Bookmark(models.Model): # 데이터베이스 테이블명과 이름이 같은 클래스
    # id 라는 컬럼이 자동으로 만들어지고 insert 하면 자동으로 1씩 증가하는 값이 저장
    # 컬럼이름 = 타입
    title = models.CharField('TITLE', max_length=100, blank=True)
    url = models.URLField('URL',unique=True)

    #class Meta:
    #    app_label = 'bookmark'

    def __str__(self):  # 자바 vo클래스에서 toString 메소드와 같은 역할
        return self.title
