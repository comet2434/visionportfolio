import numpy as np
import music21
from music21 import note, chord, stream, pitch, meter
from tqdm import tqdm
def sample(preds, temperature=1.0):
    preds = np.asarray(preds).astype('float64')
    preds = np.log(preds + 1e-8) / temperature
    exp_preds = np.exp(preds)
    preds = exp_preds / np.sum(exp_preds)
    probas = np.random.multinomial(1, preds, 1)
    return np.argmax(probas)


def generate_notes(model, note_dict, input_notes, sequence_length, vocab_length, num_notes=600, diversity=1.0,
                   rest_probability=0.1):
    backward_dict = {v: k for k, v in note_dict.items()}

    pitch_min = note.Note('C3').pitch
    pitch_max = note.Note('C5').pitch

    n = np.random.randint(0, len(input_notes) - 1)
    sequence = input_notes[n]
    start_sequence = sequence.reshape(1, sequence_length, vocab_length)
    output = []

    max_attempts = num_notes * 2
    attempts = 0

    with tqdm(total=num_notes, desc="Generating notes", unit=" note") as pbar:
        while len(output) < num_notes:
            if attempts >= max_attempts:
                print("생성 시도 횟수가 초과되었습니다. 생성된 노트 수:", len(output))
                break

            if np.random.rand() < rest_probability:
                rest_note = np.zeros(vocab_length)
                output.append(rest_note)
                pbar.update(1)
                start_sequence = np.concatenate([start_sequence[:, 1:, :], rest_note.reshape(1, 1, vocab_length)],
                                                axis=1)
                continue

            predictions = model.predict(start_sequence, verbose=0)[0]
            index = sample(predictions, diversity)

            encoded_note = np.zeros(vocab_length)
            encoded_note[index] = 1

            note_name = backward_dict.get(index, 'Rest')  # Handle unknown notes as rests

            try:
                note_obj = note.Note(note_name)
                pitch = note_obj.pitch

                if pitch.ps < pitch_min.ps or pitch.ps > pitch_max.ps:
                    start_sequence = np.concatenate(
                        [start_sequence[:, 1:, :], encoded_note.reshape(1, 1, vocab_length)], axis=1)
                    attempts += 1
                    continue

                output.append(encoded_note)
                pbar.update(1)
                start_sequence = np.concatenate([start_sequence[:, 1:, :], encoded_note.reshape(1, 1, vocab_length)],
                                                axis=1)

            except music21.pitch.PitchException as e:
                print(f"Invalid note generated: {note_name}. Error: {e}")

            attempts += 1

    final_notes = [backward_dict.get(np.argmax(note), 'Rest') for note in output]

    return final_notes


def create_pitch_from_name(note_name):
    """
    주어진 음표 이름으로부터 Pitch 객체를 생성하고 반환합니다.
    'Rest'인 경우에는 None을 반환합니다.
    """
    if note_name == 'Rest':
        return None
    try:
        pitch_obj = pitch.Pitch(note_name)
        print(f"Pitch created for {note_name}: {pitch_obj}")
        return pitch_obj
    except music21.pitch.PitchException as e:
        print(f"Error creating pitch for {note_name}: {e}")
        return None


def create_midi(final_notes, output_path='test_output.mid', selected_instrument=music21.instrument.Oboe(),
                time_signature='3/4'):
    offset = 0
    output_notes = []

    # Define possible note lengths
    note_lengths = [0.25, 0.5, 0.75, 1.0]

    for pattern in final_notes:
        length = np.random.choice(note_lengths)

        pitch_obj = create_pitch_from_name(pattern)

        if pitch_obj is None:
            continue  # Skip notes that couldn't be converted to pitch

        new_note = note.Note()
        new_note.pitch = pitch_obj
        new_note.quarterLength = length
        new_note.offset = offset
        new_note.storedInstrument = selected_instrument
        output_notes.append(new_note)

        offset += length

    # Ensure the last note to hold at least 2.0 quarter lengths
    if output_notes:
        output_notes[-1].quarterLength = max(2.0, output_notes[-1].quarterLength)
        output_notes[-1].storedInstrument = selected_instrument

    # Create a stream
    midi_stream = stream.Stream()

    # Add the time signature
    ts = meter.TimeSignature(time_signature)
    midi_stream.append(ts)

    # Add notes to the stream
    midi_stream.append(output_notes)

    # Write to MIDI file
    midi_stream.write('midi', fp=output_path)
    print(f"MIDI 파일이 {output_path}에 저장되었습니다. 사용된 악기: {selected_instrument}, 박자: {time_signature}")




