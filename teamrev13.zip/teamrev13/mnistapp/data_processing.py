from music21 import converter, instrument, note, chord
import glob
import numpy as np

def load_midi_files(file_path):
    """Load MIDI files and parse notes and chords."""
    notes = []

    for i, file in enumerate(glob.glob(file_path)):
        midi = converter.parse(file)
        print(f"Parsing {file}")

        parts = instrument.partitionByInstrument(midi)

        if parts:
            notes_to_parse = parts.parts[0].recurse()
        else:
            notes_to_parse = midi.flat.notes

        for element in notes_to_parse:
            if isinstance(element, note.Note):
                notes.append(str(element.pitch))
            elif isinstance(element, chord.Chord):
                notes.append('.'.join(str(n) for n in element.normalOrder))

        print(f"Song {i + 1} Loaded")

    print("DONE LOADING SONGS")
    return notes

def prepare_sequences(notes, sequence_length):
    """Prepare input and output sequences for the LSTM model."""
    pitches = sorted(set(item for item in notes))
    vocab_length = len(pitches)
    number_notes = len(notes)

    # 시퀀스 길이가 전체 노트보다 길면 오류를 발생시킵니다.
    if number_notes <= sequence_length:
        raise ValueError("The sequence length is greater than the number of notes available.")

    note_dict = {note: i for i, note in enumerate(pitches)}

    num_training = number_notes - sequence_length
    input_notes = np.zeros((num_training, sequence_length, vocab_length))
    output_notes = np.zeros((num_training, vocab_length))

    for i in range(num_training):
        input_sequence = notes[i: i + sequence_length]
        output_note = notes[i + sequence_length]

        for j, note in enumerate(input_sequence):
            input_notes[i][j][note_dict[note]] = 1

        output_notes[i][note_dict[output_note]] = 1

    return input_notes, output_notes, pitches, note_dict