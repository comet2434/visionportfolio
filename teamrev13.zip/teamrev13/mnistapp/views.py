from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.shortcuts import render
import json
import tensorflow as tf
import numpy as np
import base64
from PIL import Image
from io import BytesIO
import os
from django.contrib.auth.decorators import login_required
from .models import Mnistapp
# settings.py에서 정의된 BASE_DIR 경로 사용
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
model_path = os.path.join(BASE_DIR, 'models', 'mnist_model.keras')  # 새 경로에 맞게 수정

# 모델 로드
model = tf.keras.models.load_model(model_path)

def preprocess_image(image):
    # Convert to grayscale and invert colors
    image = image.convert("L")
    image = Image.eval(image, lambda x: 255 - x)  # Invert colors

    # Resize image to 28x28
    image = image.resize((28, 28), Image.LANCZOS)

    # Normalize pixel values to [0, 1]
    image_array = np.array(image) / 255.0

    # Add a new axis for model compatibility
    input_image = np.expand_dims(image_array, axis=0)

    # If necessary, expand dimensions to add a channel axis (for grey scale image)
    input_image = np.expand_dims(input_image, axis=-1)

    return input_image


@csrf_exempt
def predict(request):
    if request.method == 'POST':
        try:
            data = json.loads(request.body)
            image_data = data['input']

            # Decode and preprocess the image
            image = Image.open(BytesIO(base64.b64decode(image_data.split(',')[1])))
            input_image = preprocess_image(image)

            # Predict
            predictions = model.predict(input_image)
            pred_class = np.argmax(predictions, axis=1)[0]
            confidence_score = np.max(predictions) * 100

            return JsonResponse({
                'predictions': int(pred_class),
                'confidence': confidence_score
            })
        except Exception as e:
            print(f"Error processing the request: {e}")
            return JsonResponse({'error': str(e)}, status=500)
    else:
        return render(request, 'mnistapp/index.html')

@login_required
def index(request):
    records = Mnistapp.objects.filter(user=request.user)
    context = {'records': records}
    return render(request, 'mnistapp/index.html')



