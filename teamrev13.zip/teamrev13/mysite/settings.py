import os
# Python의 표준 라이브러리인 pathlib에서 Path 클래스를 가져옵니다.
# 이 클래스는 파일 경로와 관련된 작업을 수행하는 데 사용됩니다.

from pathlib import Path

# 프로젝트의 기본 디렉터리를 정의합니다. 현재 파일(__file__)의 경로를 가져와서
# 절대 경로로 변환하고, 그 부모 디렉터리를 두 번 거슬러 올라가서 프로젝트의
# 기본 디렉터리를 얻습니다.
# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent
# 장고 애플리케이션의 보안에 사용되는 랜덤한 문자열입니다. 애플리케이션의 보안에 매우 중요하며,
# 이 값을 유출하면 보안에 위협이 될 수 있습니다.
# Quick-start development settings - unsuitable for production
# See https://docs.djangoproject.com/en/5.0/howto/deployment/checklist/
# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = "django-insecure-m8@et$v7y04r$7qt+dcg2j%51n^^-z+i8=jfdvw%w@4u6w!y#("
# 디버그 모드를 활성화합니다. 이것은 개발 중에만 사용해야하며, 배포할 때는 비활성화해야 합니다.
# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = True
# 애플리케이션이 서비스할 수 있는 호스트의 리스트입니다. 배포할 때 이 값을 업데이트하여
# 허용할 호스트를 지정해야 합니다. 개발모드인 경우에는 값을 지정하지 않으면 ['localhost','127.0.0.1']로 간주
ALLOWED_HOSTS = ['192.168.0.54', 'localhost', '127.0.0.1']
# 설치된 애플리케이션의 목록입니다. 각 애플리케이션은 Django 프로젝트에서 사용되는 기능을 정의합니다.
# Application definition
INSTALLED_APPS = [
    'users',
    "django.contrib.admin",
    "django.contrib.auth",
    "django.contrib.contenttypes",
    "django.contrib.sessions",
    "django.contrib.messages",
    "django.contrib.staticfiles",
    "widget_tweaks",
    'homebook',
    "bookmark",
    "community",
    # 애플리케이션의 기본 설정을 사용하는 경우 : Django는 애플리케이션 디렉토리 내부의 apps.py 파일에 정의된 기본 설정 클래스를 자동으로 찾음(community/apps.py)
    "blog.apps.BlogConfig",  # 애플리케이션의 설정 클래스를 명시적으로 지정
    'polls',
    'photo.apps.PhotoConfig',
    'goods',
    'cart',
    'orders',
    'ohistory',
    'board',
    'wafermap',
    'mnistapp',
]
# 요청 및 응답 처리를 제어하는 데 사용되는 미들웨어의 목록입니다.
MIDDLEWARE = [
    "django.middleware.security.SecurityMiddleware",
    "django.contrib.sessions.middleware.SessionMiddleware",
    "django.middleware.common.CommonMiddleware",
    "django.middleware.csrf.CsrfViewMiddleware",
    "django.contrib.auth.middleware.AuthenticationMiddleware",
    "django.contrib.messages.middleware.MessageMiddleware",
    "django.middleware.clickjacking.XFrameOptionsMiddleware",
]
# "yoursite.urls": URLconf 모듈의 경로를 지정합니다. 이 모듈은 URL 경로를 뷰로 매핑하는 데 사용됩니다.
ROOT_URLCONF = "mysite.urls"
# 템플릿 설정입니다. 이 설정은 Django가 템플릿 파일을 로드하는 방법을 정의합니다.
TEMPLATES = [
    {
        "BACKEND": "django.template.backends.django.DjangoTemplates",
        "DIRS": [os.path.join(BASE_DIR, 'templates')],  # [] 추가함, 프로젝트 전체의 템플릿 디렉터리를 지정
        "APP_DIRS": True,  # 각 앱의 "templates" 디렉터리를 탐색하도록 함
        "OPTIONS": {
            "context_processors": [
                "django.template.context_processors.debug",
                "django.template.context_processors.request",
                "django.contrib.auth.context_processors.auth",
                "django.contrib.messages.context_processors.messages",
            ],
        },
    },
]
# WSGI 애플리케이션의 경로를 지정합니다. WSGI 애플리케이션은 웹 서버와 Django 애플리케이션 간의 통신을 관리합니다.
WSGI_APPLICATION = "mysite.wsgi.application"

# 데이터베이스 설정입니다. 이 설정은 데이터베이스 연결 및 구성을 정의합니다.
# Database
# https://docs.djangoproject.com/en/5.0/ref/settings/#databases

DATABASES = {
    "default": {
        "ENGINE": "django.db.backends.sqlite3",
        "NAME": BASE_DIR / "db.sqlite3",  # Oracle 사용시 변경해야 함
    }
}

# 사용자 비밀번호의 유효성을 검사하는 데 사용되는 검증기의 목록입니다.
# Password validation
# https://docs.djangoproject.com/en/5.0/ref/settings/#auth-password-validators
AUTH_PASSWORD_VALIDATORS = [
    {
        "NAME": "django.contrib.auth.password_validation.UserAttributeSimilarityValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.MinimumLengthValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.CommonPasswordValidator",
    },
    {
        "NAME": "django.contrib.auth.password_validation.NumericPasswordValidator",
    },
]

# Internationalization
# https://docs.djangoproject.com/en/5.0/topics/i18n/
# 기본 언어 코드를 설정합니다.
# LANGUAGE_CODE = "en-us"
LANGUAGE_CODE = "ko-kr"  # 관리자 내용에서 한글이 됨
# 기본 시간대를 설정합니다.
# TIME_ZONE = "UTC"
TIME_ZONE = "Asia/Seoul"
# 다국어 지원을 사용할지 여부를 결정합니다.
USE_I18N = True
# 시간대를 사용할지 여부를 결정합니다.
USE_TZ = True

# 정적 파일의 URL을 설정합니다.
# Static files (CSS, JavaScript, Images)
# https://docs.djangoproject.com/en/5.0/howto/static-files/

STATIC_URL = "/static/"  # ==> http://yourdomain.com/static/yourfile.css
# STATIC_URL = "static/" : # ==> http://yourdomain.com/yourapp/static/yourfile.css
# 프로젝트 레벨에서 별도로 관리할 정적 파일 디렉터리를 추가할 수 있습니다.
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'static')]  # 추가함
# Default primary key field type
# https://docs.djangoproject.com/en/5.0/ref/settings/#default-auto-field
# 모델에 대한 기본 자동 생성 필드를 설정합니다. 이것은 Django 3.2에서 추가된 설정입니다.
DEFAULT_AUTO_FIELD = "django.db.models.BigAutoField"
# 추가: 설정은 Django 프로젝트에서 업로드된 파일(예: 사용자 업로드 이미지, 문서 등)을 처리하고
# 제공하기 위한 설정입니다. 이 설정들은 정적 파일(static files)과는 별도로, 사용자나 어드민이
# 업로드한 파일들을 관리하기 위해 사용됩니다.
MEDIA_URL = '/media/'  # 추가함
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')  # 추가함

TAGGIT_CASE_INSENSITIVE = True
TAGGIT_LIMIT = 50

DISQUS_SHORTNAME = 'skysnow'
LOGIN_REDIRECT_URL = '/'

AUTH_USER_MODEL = 'users.CustomUser'

SESSION_ENGINE = 'django.contrib.sessions.backends.file'
SESSION_FILE_PATH = os.path.join(BASE_DIR, 'tmp')
CSRF_USE_SESSIONS = True
#LOGOUT_REDIRECT_URL = 'users:login'
