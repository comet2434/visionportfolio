from django.contrib import admin
from django.urls import path, include
from django.conf.urls.static import static
from django.conf import settings
from .views import HomeView
from mysite.views import HomeView, UserCreateView, UserCreateDoneTV

urlpatterns = [
    path("", HomeView.as_view(), name='home'),
    path("admin/", admin.site.urls),
    path('users/', include('users.urls')),
    path('accounts/', include('django.contrib.auth.urls')),
    path('accounts/register/', UserCreateView.as_view(), name='register'),
    path('accounts/register/done/', UserCreateDoneTV.as_view(), name='register_done'),
    path("bookmark/", include("bookmark.urls")),
    path("community/", include("community.urls")),
    path('blog/', include('blog.urls')),
    path('polls/', include('polls.urls')),
    path('photo/', include('photo.urls', namespace='photo')),
    path('homebook/', include('homebook.urls')),
    path('wafermap/', include('wafermap.urls')),
    path('mnistapp/', include('mnistapp.urls')),
    path('goods/', include('goods.urls')),
    path('cart/', include('cart.urls')),
    path('orders/', include('orders.urls')),
    path('ohistory/', include('ohistory.urls')),
    path('board/', include('board.urls')),
]

if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
