from django.contrib.auth.models import User
from django.db import models
from users.models import CustomUser
# Create your models here.
class Homebook(models.Model):
    day = models.DateField()
    section = models.CharField(max_length=50)
    accounttitle = models.CharField(max_length=100)
    remark = models.CharField(max_length=3000)
    revenue = models.PositiveIntegerField()
    expense = models.PositiveIntegerField()
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='homebooks')

    class Meta:
        db_table = 'homebook'

    def __str__(self):  # 객체 표현 양식
        return f'{self.day},\t{self.section},\t{self.accounttitle}({self.user.username})'
