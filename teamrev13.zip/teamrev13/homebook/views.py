from django.shortcuts import render, get_object_or_404, \
    redirect  # get_object_or_404 ~ 데이터베이스에서 객체를 가져오거나 객체가 없는 경우 404오류를 반환
from django.contrib.auth.decorators import login_required
from .models import Homebook  # 가계부 기록을 저장하는 모델
from .forms import RecordForm  # 가계부 기록을 생성하거나 수정할 때 사용하는 폼


@login_required
def home(request):
    records = Homebook.objects.filter(user=request.user)
    context = {'records': records}
    return render(request, 'homebook/home.html', context)


@login_required
def create_record(request):  # 새로운 가계부 기록
    if request.method == 'POST':
        form = RecordForm(request.POST)  # 폼 데이터를 바탕으로 새로운 기록을 생성
        if form.is_valid():  # 폼이 유효하면
            record = form.save(commit=False)  # 새로운 기록 생성
            record.user = request.user
            record.save()  # 디비 저장 완료
            return redirect('homebook:detail', record_id=record.id)
    else:
        form = RecordForm()  # 빈 폼을 만들고

    context = {'form': form}
    return render(request, 'homebook/create.html', context)


@login_required
def detail(request, record_id):  # 특정 가계부 기록의 세부 정보를 표시
    # 주어진 record_id와 현재 사용자로 가계부 기록을 가져옴
    # 기록이 존재하지 않으면 404 오류를 반환함
    record = get_object_or_404(Homebook, id=record_id, user=request.user)
    # 기록을 context에 저장하고 이를 detail.html 템플릿에 전달
    context = {'record': record}
    return render(request, 'homebook/detail.html', context)


@login_required
def update_record(request, record_id):
    record = get_object_or_404(Homebook, id=record_id, user=request.user)
    if request.method == 'POST':
        form = RecordForm(request.POST, instance=record)
        if form.is_valid():
            print('조건문1 통과')
            form.save()  # 디비 저장 완료
            print('조건문2 통과')
            return redirect('homebook:detail', record_id=record.id)
        else:
            print('조건문3 통과', form.errors)
    else:
        form = RecordForm(instance=record)  # 기록의 현재 데이터를 가진 폼을 만들고

    context = {'form': form}
    return render(request, 'homebook/update.html', context)


@login_required
def delete_record(request, record_id):
    record = get_object_or_404(Homebook, id=record_id, user=request.user)
    if request.method == 'POST':
        record.delete()
        return redirect('homebook:home')

    context = {'record': record}
    return render(request, 'homebook/delete.html', context)
