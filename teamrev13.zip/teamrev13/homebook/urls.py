from django.urls import path
from . import views

app_name = 'homebook'

urlpatterns = [
    path('', views.home, name='home'),
    path('create/', views.create_record, name='create'),
    path('<int:record_id>/', views.detail, name='detail'),
    path('<int:record_id>/update/', views.update_record, name='update'),
    path('<int:record_id>/delete/', views.delete_record, name='delete'),
]
