from django.contrib import admin
from homebook.models import Homebook

admin.site.register(Homebook)
# Register your models here.
