from django import forms
from .models import Homebook

class RecordForm(forms.ModelForm):
    class Meta:
        model = Homebook
        exclude = ['user']  # user 필드는 로그인한 사용자로부터 자동적으로 가져와서 처리

    def clean(self):
        cleaned_data = super().clean()
        revenue = cleaned_data.get('revenue')
        expense = cleaned_data.get('expense')
        if revenue == 0 and expense == 0:
            raise forms.ValidationError('수입과 지출 중 적어도 하나는 입력되어야 합니다.')


