from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from orders import views as ohistory_views
from .views import AddToOhistoryView
from .views import AddToOhistorysView

app_name = 'orders'

urlpatterns = [
    path('', views.home, name='home'),
    path('create/', views.create_record, name='create'),
    path('<int:record_id>/', views.detail, name='detail'),
    path('<int:record_id>/update/', views.update_record, name='update'),
    path('<int:record_id>/delete/', views.delete_record, name='delete'),
    path('ohistory/create/<int:record_id>/', views.ohistory_create_record, name='ohistory_create_record'),
    path('<int:pk>/add_to_ohistory/', AddToOhistoryView.as_view(), name='add_to_ohistory'),
    path('add_to_ohistorys/', AddToOhistorysView.as_view(), name='add_to_ohistorys'),
    path('ohistory/', views.ohistorypage, name='ohistory_page'),
]
