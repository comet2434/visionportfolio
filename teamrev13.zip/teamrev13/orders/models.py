from django.contrib.auth.models import User
from django.db import models
import datetime
from users.models import CustomUser

class Orders(models.Model):
    gid = models.CharField(max_length=50)
    gname = models.CharField(max_length=50)
    mid = models.CharField(max_length=50)
    mname = models.CharField(max_length=50)
    price = models.PositiveIntegerField()
    amount = models.PositiveIntegerField()
    date = models.DateTimeField(default=datetime.datetime.now)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='orders')

    class Meta:
        db_table = 'orders'

    def __str__(self):  # 객체 표현 양식
        return f'{self.gid}, {self.gname}, {self.user.id}, {self.user.username},  {self.price}, {self.amount}, {self.date}, {self.user.username}'
