from django.shortcuts import render, get_object_or_404, \
    redirect  # get_object_or_404 ~ 데이터베이스에서 객체를 가져오거나 객체가 없는 경우 404오류를 반환
from django.contrib.auth.decorators import login_required
from .forms import OrderForm
from cart.models import Cart
from django.views import View
from ohistory.models import Ohistory
from django.urls import reverse
from django.contrib import messages
from django.db import IntegrityError, transaction
from .models import Orders
from users.models import CustomUser
from goods.models import Goods
from django.contrib.auth.mixins import LoginRequiredMixin


@login_required
def home(request):
    records = Orders.objects.filter(user=request.user)
    context = {'records': records}
    return render(request, 'orders/home.html', context)


@login_required
def create_record(request):
    if request.method == 'POST':
        form = OrderForm(request.POST, request.FILES)  # 폼 데이터를 바탕으로 새로운 기록을 생성
        if form.is_valid():  # 폼이 유효하면
            record = form.save(commit=False)  # 새로운 기록 생성
            record.user = request.user
            record.save()  # 디비 저장 완료
            return redirect('orders:detail', record_id=record.id)
    else:
        form = OrderForm()  # 빈 폼을 만들고

    context = {'form': form}
    return render(request, 'orders/create.html', context)


@login_required
def detail(request, record_id):
    record = get_object_or_404(Orders, id=record_id, user=request.user)
    # 기록을 context에 저장하고 이를 detail.html 템플릿에 전달
    context = {'record': record}
    return render(request, 'orders/detail.html', context)


@login_required
def update_record(request, record_id):
    record = get_object_or_404(Orders, id=record_id, user=request.user)
    if request.method == 'POST':
        form = OrderForm(request.POST, instance=record)
        if form.is_valid():
            print('조건문1 통과')
            form.save()  # 디비 저장 완료
            print('조건문2 통과')
            return redirect('orders:detail', record_id=record.id)
        else:
            print('조건문3 통과', form.errors)
    else:
        form = OrderForm(instance=record)  # 기록의 현재 데이터를 가진 폼을 만들고

    context = {'form': form}
    return render(request, 'orders/update.html', context)


@login_required
def delete_record(request, record_id):
    record = get_object_or_404(Orders, id=record_id, user=request.user)
    if request.method == 'POST':
        record.delete()
        return redirect('orders:home')

    context = {'record': record}
    return render(request, 'orders/delete.html', context)


@login_required()
def create_order(request, record_id):
    cart_record = get_object_or_404(Cart, id=record_id)
    if request.method == 'POST':
        form = OrderForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('orders:order_success')  # 주문 성공 페이지로 리디렉션 (정의 필요)
    else:
        initial_data = {
            'gid': cart_record.gid,
            'gname': cart_record.gname,
            'price': cart_record.price,
            'camount': cart_record.camount,
        }
        form = OrderForm(initial=initial_data)

    return render(request, 'orders/create_order.html', {'form': form})


@login_required
def ohistory_create_record(request, record_id):
    record = get_object_or_404(Orders, id=record_id, user=request.user)
    if request.method == 'POST':
        record.create()
        return redirect('ohistory:create_order')

    context = {'record': record}
    return render(request, 'ohistory/create.html', context)


def ohistorypage(request):
    records = Cart.objects.all()
    return render(request, 'orders/ohistorypage.html', {'records': records})


class AddToOhistorysView(LoginRequiredMixin, View):
    def post(self, request):
        selected_records = request.POST.getlist('selected_records')
        total_amount = 0

        try:
            with transaction.atomic():
                for record_id in selected_records:
                    orders = get_object_or_404(Orders, pk=record_id)
                    amount = int(request.POST.get(f'amount_{record_id}', 1))
                    total_amount += orders.price * amount

                    goods = get_object_or_404(Goods, gid=orders.gid)

                    if goods.amount < amount:
                        messages.error(request, f'상품 {goods.gname}의 재고가 부족합니다.')
                        return redirect('orders:list')

                    goods.amount -= amount
                    goods.save()

                    new_ohistory_item = Ohistory(
                        gid=orders.gid,
                        gname=orders.gname,
                        mid=request.user.id,
                        mname=request.user.username,
                        price=orders.price,
                        amount=amount,
                        user=request.user,
                    )
                    new_ohistory_item.save()

                user_profile = get_object_or_404(CustomUser, id=request.user.id)

                if user_profile.money >= total_amount:
                    user_profile.money -= total_amount
                    user_profile.save()
                    messages.success(request, '선택한 상품이 결제되었습니다.')
                else:
                    messages.error(request, '잔액이 부족합니다.')
                    return redirect('orders:list')

        except IntegrityError as e:
            messages.error(request, f'결제하는 중 오류가 발생했습니다: {e}')
            return redirect('orders:list')

        return redirect('ohistory:home')

class AddToOhistoryView(LoginRequiredMixin, View):
    def post(self, request, pk):
        try:
            with transaction.atomic():
                order = get_object_or_404(Orders, pk=pk)
                amount = int(request.POST.get(f'amount_{pk}', 1))
                total_amount = order.price * amount

                goods = get_object_or_404(Goods, gid=order.gid)

                if goods.amount < amount:
                    messages.error(request, f'상품 {goods.gname}의 재고가 부족합니다.')
                    return redirect('orders:detail', record_id=pk)

                goods.amount -= amount
                goods.save()

                new_ohistory_item = Ohistory(
                    gid=order.gid,
                    gname=order.gname,
                    mid=request.user.id,
                    mname=request.user.username,
                    price=order.price,
                    amount=amount,
                    user=request.user,
                )
                new_ohistory_item.save()

                user_profile = get_object_or_404(CustomUser, id=request.user.id)

                if user_profile.money >= total_amount:
                    user_profile.money -= total_amount
                    user_profile.save()
                    messages.success(request, '상품이 성공적으로 결제되었습니다.')
                else:
                    messages.error(request, '잔액이 부족합니다.')
                    return redirect('orders:detail', record_id=pk)

        except IntegrityError as e:
            messages.error(request, f'결제하는 중 오류가 발생했습니다: {e}')
            return redirect('orders:detail', record_id=pk)

        return redirect('ohistory:home')
