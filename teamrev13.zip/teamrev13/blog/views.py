from django.db.models import Q
from django.shortcuts import render
from django.views.generic import ListView, DetailView, FormView
from django.views.generic import ArchiveIndexView, YearArchiveView, MonthArchiveView
from django.views.generic import DayArchiveView, TodayArchiveView

from blog.forms import PostSearchForm
from blog.models import Post


# --- ListView
class PostLV(ListView):
    model = Post
    template_name = 'blog/post_all.html'
    context_object_name = 'posts'
    paginate_by = 2


# --- DetailView
class PostDV(DetailView):
    model = Post


# --- ArchiveView
class PostAV(ArchiveIndexView):
    model = Post
    date_field = 'modify_dt'


class PostYAV(YearArchiveView):
    model = Post
    date_field = 'modify_dt'
    make_object_list = True


class PostMAV(MonthArchiveView):
    model = Post
    date_field = 'modify_dt'


class PostDAV(DayArchiveView):
    model = Post
    date_field = 'modify_dt'


class PostTAV(TodayArchiveView):
    model = Post
    date_field = 'modify_dt'


class SearchFormView(FormView):
    form_class = PostSearchForm
    template_name = 'blog/post_search.html'

    def form_valid(self, form):  # 유효성 검사 로직
        searchWord = form.cleaned_data['search_word']
        # Q : 메소드의 매칭조건을 다양하게 구사할 수 있게 함
        post_list = Post.objects.filter(
            Q(title__icontains=searchWord) |
            Q(description__icontains=searchWord) |
            Q(content__icontains=searchWord)).distinct()
        context = {
            'form': form,
            'search_term': searchWord,
            'object_list': post_list,
        }
        # 아래와 동일한 내용입니다.
        # context = {}
        # context['form'] = form
        # context['search_term'] = searchWord
        # context['object_list'] = post_list
        return render(self.request, self.template_name, context)
