from django.contrib import admin
from blog.models import Post


@admin.register(Post)
class PostAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'modify_dt')
    list_filter = ('modify_dt',)
    search_fields = ('title', 'content')
    # title 필드의 내용을 바탕으로 slug 필드를 자동으로 채움
    # 예를 들어, 제목이 "My First Post"인 경우, 슬러그 필드는 자동으로
    # "my-first-post"로 채움
    prepopulated_fields = {'slug': ('title',)}
