from django.db import models
from django.urls import reverse

'''
이 Post 모델은 블로그 게시물을 데이터베이스에 저장하고, 이를 다양한
방식으로 관리할 수 있도록 함. 각 필드와 메서드는 게시물의 정보를
효과적으로 관리하고 표시하는 데 도움을 줌.
'''


class Post(models.Model):
    title = models.CharField(verbose_name='TITLE', max_length=50)
    slug = models.SlugField('SLUG', unique=True, allow_unicode=True, help_text='제목 별칭을 한 단어로~')
    description = models.CharField('DESCRIPTION', max_length=100, blank=True, help_text='간단한 텍스트 설명~')
    content = models.TextField('CONTENT')  # 길이 제한 없음
    # 객체가 생성될 때 자동으로 현재 날짜와 시간으로 설정
    create_dt = models.DateTimeField('CREATE DATE', auto_now_add=True)
    # 객체가 저장될 때마다 현재 날짜와 시간으로 자동 업데이트
    modify_dt = models.DateTimeField('MODIFY DATE', auto_now=True)


class Meta:
    verbose_name = 'post'  # 단수형 이름
    verbose_name_plural = 'posts'  # 복수형 이름
    db_table = 'blog_posts'  # 데이타베이스 테이블 이름
    ordering = ('-modify_dt',)  # 기본 정렬 순서를 modify_dt 필드를 기준으로 내림차순


def __str__(self):
    return self.title


# 객체의 절대 URL을 반환합니다. 이는 게시물의 상세 페이지로의 링크를 제공
def get_absolute_url(self):
    # reverse 함수는 URL 패턴 이름 'blog:post_detail'과 슬러그 값을 사용하여 URL을 생성
    return reverse('blog:post_detail', args=(self.slug,))


# 수정 날짜를 기준으로 이전 게시물을 반환
def get_previous(self):
    return self.get_previous_by_modify_dt()


# 수정 날짜를 기준으로 다음 게시물을 반환
def get_next(self):
    return self.get_next_by_modify_dt()
