from django import forms
from .models import Article
# 템플릿의 입력폼을 만들 때 사용되는 클래스
class Form(forms.ModelForm):
    class Meta:
        model = Article
        #id, cdate는 폼에서 입력받지 않는다.
        fields = ['name','title','contents','url','email']