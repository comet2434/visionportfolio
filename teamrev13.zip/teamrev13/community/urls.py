from django.urls import path
from . import views
from .views import CommunityLV

app_name = 'community'
urlpatterns = [
    path("", CommunityLV.as_view(), name="index"),
    path('write/', views.write, name='article_write'),
    path('list/', views.list, name='article_list'),
    path('view/<int:num>/', views.view, name='article_view'),

    #path('write/', views.write, name='write'),
    #path('list/', views.list, name='list'),
    #path('view/<int:num>/', views.view, name='view'),
]
