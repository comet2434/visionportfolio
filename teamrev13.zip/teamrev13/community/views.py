from django.shortcuts import render
from django.views.generic import ListView
from .forms import Form
from .models import Article

# MVT 패턴에서 V (컨터롤러 역할)
# 랜더링 함수 만들기 ==> HTML을 완성시켜 주기 위한 함수

# 데이터 입력 폼이 있는 템플릿에 사용
def write(request):
    if request.method == 'POST':
        form = Form(request.POST)
        if form.is_valid():  # 폼의 형식이 제대로 갖춰졌다면
            form.save()  # 데이터 베이스에 저장
    else:
        form = Form()
    return render(request, 'community/article_write.html', {'form': form})
    #return render(request, 'write.html', {'form': form})


def list(request):
    articles = Article.objects.all()
    # articleList = Article.objects.all()
    return render(request, 'community/article_list.html', {'articles': articles})
    #return render(request, 'list.html', {'articleList': articleList})


def view(request, num=1): # 상세보기, 1은 default 값
    # 으로 미설정시 적용
    article = Article.objects.get(id=num)
    return render(request, 'community/article_view.html', {'article': article})
    #return render(request, 'view.html', {'article': article})

class CommunityLV(ListView): # 목록 보기용 제어
    model = Article #디비의 해당 테이블 지정
    context_object_name = 'articleList'
    template_name = 'community/article_list.html'
    context_object_name = 'articles'
