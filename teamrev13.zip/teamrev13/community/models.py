from django.db import models

# Create your models here.
class Article(models.Model):
    # id 생략 (자동 증가)
    name = models.CharField(max_length=50) # 기사작성인
    title = models.CharField(max_length=50) # 기사제목
    contents = models.TextField(editable=True) # 기사내용
    url = models.URLField() #기사 링크 URL
    email = models.EmailField() # 작성인 이메일
    cdate = models.DateTimeField(auto_now_add=True) # 기사등재일
