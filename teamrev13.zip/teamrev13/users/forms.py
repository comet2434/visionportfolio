from django import forms
from .models import CustomUser
from django.contrib.auth.forms import UserCreationForm

class CustomUserForm(forms.ModelForm):
    class Meta:
        model = CustomUser
        fields = ['id', 'username', 'email', 'password', 'address', 'phone', 'money']

    def clean(self):
        cleaned_data = super().clean()
        money = cleaned_data.get('money')

class SignUpForm(UserCreationForm):
    address = forms.CharField(max_length=255, required=True)
    phone = forms.CharField(max_length=15, required=True)
    money = forms.DecimalField(max_digits=10, decimal_places=2, initial=0.0, required=True)

    class Meta:
        model = CustomUser
        fields = ('username', 'password1', 'password2', 'address', 'phone', 'money')
