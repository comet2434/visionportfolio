from django.contrib.auth import login as auth_login, authenticate
from django.shortcuts import render, redirect, get_object_or_404
from .forms import SignUpForm, CustomUserForm
from django.contrib.auth.decorators import login_required
from users.models import CustomUser
from django.contrib.auth import get_user_model

def register(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')  # 사용자가 등록되고 홈페이지로 리다이렉트
    else:
        form = SignUpForm()

    return render(request, 'users/register.html', {'form': form})
def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = authenticate(request, username=username, password=password)
        if user is not None:
            login(request, user)
            return redirect('home')  # 'home'은 사용자가 로그인 후 이동할 URL
        else:
            # Handle invalid login
            pass
    return render(request, 'users/login.html')


def signup(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            user = form.save()
            address = form.cleaned_data.get('address')
            phone = form.cleaned_data.get('phone')
            money = form.cleaned_data.get('money')

            CustomUser.objects.create(username=user.username, address=address, phone=phone, money=money)

            raw_password = form.cleaned_data.get('password1')
            user = authenticate(username=user.username, password=raw_password)
            login(request, user)
            return redirect('register_done')  # 프로필 보기 페이지로 리디렉션
    else:
        form = SignUpForm()
    return render(request, 'registration/register.html', {'form': form})
@login_required
def profile_edit(request):
    customer_profile = get_object_or_404(CustomUser, username=request.user.username)

    if request.method == 'POST':
        form = CustomUserForm(request.POST, instance=customer_profile)
        if form.is_valid():
            form.save()
            return redirect('profile_view')  # 프로필 보기 페이지로 리디렉션
    else:
        form = CustomUserForm(instance=customer_profile)
    return render(request, 'users/profile_edit.html', {'form': form})
@login_required
def profile_view(request):
    customer_profile = get_object_or_404(CustomUser, username=request.user.username)
    return render(request, 'home.html', {'users_profile': customer_profile})
    #return render(request, 'users/profile_view.html', {'users_profile': customer_profile})

@login_required
def list(request):
    records = CustomUser.objects.filter(username=request.user.username)
    context = {'records': records}
    return render(request, 'users/list.html', context)

@login_required
def detail(request, record_id):
    record = get_object_or_404(CustomUser, id=record_id, username=request.user.username)
    context = {'record': record}
    return render(request, 'users/detail.html', context)

@login_required
def delete_record(request, record_id):
    record = get_object_or_404(CustomUser, id=record_id, username=request.user.username)
    if request.method == 'POST':
        record.delete()
        return redirect('users:list')
    context = {'record': record}
    return render(request, 'users/delete.html', context)


@login_required
def update_record(request, record_id):
    record = get_object_or_404(CustomUser, id=record_id, username=request.user.username)
    if request.method == 'POST':
        form = CustomUserForm(request.POST, instance=record)
        if form.is_valid():
            print('조건문1 통과')
            form.save()  # 디비 저장 완료
            print('조건문2 통과')
            return redirect('users:detail', record_id=record.id)
        else:
            print('조건문3 통과', form.errors)
    else:
        form = CustomUserForm(instance=record)  # 기록의 현재 데이터를 가진 폼을 만들고

    context = {'form': form}
    return render(request, 'users/update.html', context)

def user_profile(request):
    User = get_user_model()
    user = User.objects.get(id=request.user.id)
    return render(request, 'user_profile.html', {'user': user})
