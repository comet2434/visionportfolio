from django.urls import path
from . import views

app_name = 'users'
urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('signup/', views.signup, name='signup'),
    path('profile_edit/', views.profile_edit, name='profile_edit'),
    path('profile_view/', views.profile_view, name='profile_view'),
    path('register_done/', views.signup, name='register_done'),
    path('list/', views.list, name='list'),
    path('<int:record_id>/', views.detail, name='detail'),
    path('<int:record_id>/update/', views.update_record, name='update'),
    path('<int:record_id>/delete/', views.delete_record, name='delete'),

]
