from django.urls import path
from . import views

app_name = 'polls'
urlpatterns = [
    # /polls/
    path('', views.IndexView.as_view(), name='index'),
    # /polls/5/
    path('<int:pk>/', views.DetailView.as_view(), name='detail'),
    # /polls/5/results/
    path('<int:pk>/results/', views.ResultsView.as_view(), name='results'),
    # /polls/5/vite/
    path('<int:question_id>/vote/', views.vote, name='vote'),
    # question_id를 pk로 사용하려면 views.py 에서 vote 정의에 question_id 대신에 pk를 사용해야 함

]
