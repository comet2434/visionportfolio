from django.urls import path
from . import views
from django.conf import settings
from django.conf.urls.static import static
from orders import views as orders_views
from .views import AddToOrderView
from .views import AddToOrdersView

app_name = 'cart'

urlpatterns = [
    path('', views.home, name='home'),
    path('create/', views.create_record, name='create'),
    path('<int:record_id>/', views.detail, name='detail'),
    path('<int:record_id>/update/', views.update_record, name='update'),
    path('<int:record_id>/delete/', views.delete_record, name='delete'),
    path('orders/create/<int:record_id>/', views.orders_create_record, name='orders_create_record'),
    path('<int:pk>/add_to_order/', AddToOrderView.as_view(), name='add_to_order'),
    path('add_to_orders/', AddToOrdersView.as_view(), name='add_to_orders'),
    path('order/', views.orderpage, name='order_page'),
]
