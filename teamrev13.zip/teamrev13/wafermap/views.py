from django.http import HttpResponse
from django.shortcuts import render
from .forms import InverseMapForm, ReconMapForm, ConversionMapForm
from .models import UploadedFile
import subprocess
from django.contrib.auth.decorators import login_required

def inverse_map(request):
    result = None
    if request.method == 'POST':
        form = InverseMapForm(request.POST)
        if form.is_valid():
            try:
                # inversemap.py 스크립트를 실행
                process = subprocess.run(['python', 'wafermap/inversemap.py'], capture_output=True, text=True)
                result = process.stdout
            except Exception as e:
                result = f"Error running inversemap.py: {str(e)}"
    else:
        form = InverseMapForm()

    return render(request, 'wafermap/inversemap.html', {'form': form, 'result': result})


def recon_map(request):
    result = None
    if request.method == 'POST':
        form = ReconMapForm(request.POST)
        if form.is_valid():
            try:
                # reconmap.py 스크립트를 실행
                process = subprocess.run(['python', 'wafermap/reconmap.py'], capture_output=True, text=True)
                result = process.stdout
            except Exception as e:
                result = f"Error running reconmap.py: {str(e)}"
    else:
        form = ReconMapForm()

    return render(request, 'wafermap/reconmap.html', {'form': form, 'result': result})

@login_required
def conversion_map(request):
    records = UploadedFile.objects.filter(user=request.user)
    context = {'records': records}
    return render(request, 'wafermap/conversionmap.html', context)
