import openpyxl
import pandas as pd
import xlsxwriter
import tkinter as tk
from tkinter import filedialog
import os
import shutil
def select_file():
    root = tk.Tk()
    root.withdraw()
    file_path = filedialog.askopenfilename(title="Select a file",
                                           filetypes=[("ASC files", "*.ASC"), ("All files", "*.*")])

    if file_path:
        print(f"Selected file: {file_path}")
    else:
        print("File selection cancelled.")
    print(f"file_path : {file_path}")
    return file_path

def copy_files(file_path):
    directory = os.path.dirname(file_path)
    base_name = os.path.basename(file_path)
    name, ext = os.path.splitext(base_name)

    fix_file1 = os.path.join(directory, 'VISION01' + ext)
    fix_file2 = os.path.join(directory, 'VISION01S' + ext)
    s_file_path = os.path.join(directory, name + 'S' + ext)
    fix_file3 = os.path.join(directory, 'VISION01A' + ext)
    a_file_path = os.path.join(directory, name + 'A' + ext)

    try:
        # Copy the original file to fix_file1
        shutil.copy(file_path, fix_file1)
        print(f"Copied {file_path} to {fix_file1}")

        # Check and copy the 'S' file if it exists
        if os.path.exists(s_file_path):
            shutil.copy(s_file_path, fix_file2)
            print(f"Copied {s_file_path} to {fix_file2}")
            # Check and copy the 'A' file if it exists
            shutil.copy(a_file_path, fix_file3)
            print(f"Copied {a_file_path} to {fix_file3}")
        else:
            print(f"Neither {s_file_path} nor {a_file_path} exist.")
    except Exception as e:
        print(f"Failed to copy files: {e}")
def wafermap_x_y(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            data_lines = file.readlines()

        third_line = data_lines[2]
        fourth_line = data_lines[3]

        third_value = third_line.replace('X:', '')
        fourth_value = fourth_line.replace('Y:', '')

        mapx1 = int(third_value)
        mapy1 = int(fourth_value)

        print(f"3줄 내용 : {third_line} 'X:' 제외하면 : {mapx1}")
        print(f"4줄 내용 : {fourth_line} 'Y:' 제외하면 : {mapy1}")

        return mapx1, mapy1  # mapx1과 mapy1 값을 반환하도록 수정

    except (FileNotFoundError, IndexError) as e:
        print(f"Error: {e}")
        return None, None


def count_rows(file_path):
    try:
        with open(file_path, 'r', encoding='utf-8') as file:
            lines = file.readlines()  # 파일의 모든 줄을 읽어 리스트로 저장
            num_rows = len(lines)  # 리스트의 길이를 통해 행의 수 계산
            return num_rows

    except FileNotFoundError:
        print(f"Error: File '{file_path}' not found.")
        return 0  # 파일이 없으면 0을 반환

def asc_excel_map(file_path, output_excel_path):
    # Initialize workbook and select active worksheet
    wb = openpyxl.Workbook()
    ws = wb.active

    with open(file_path, 'r', encoding='utf-8') as file:
        lines = file.readlines()

    row = 1
    for line in lines:
        col = 1
        for char in line.rstrip():  # Use rstrip() to remove any trailing newlines
            ws.cell(row=row, column=col).value = char
            col += 1
        row += 1

    # Save the workbook
    wb.save(output_excel_path)


def zigzag_sum_ABC(input_excel_path, output_excel_path, start_position):
    # Load the workbook and select the active worksheet
    wb = openpyxl.load_workbook(input_excel_path)
    ws = wb.active

    def apply_zigzag(start_row, end_row, start_col, end_col, current_number, direction):
        down = True

        if direction == 'right-down':
            col_range = range(start_col, end_col + 1)
            row_range_up = range(start_row, end_row + 1)
            row_range_down = range(end_row, start_row - 1, -1)
        elif direction == 'right-up':
            col_range = range(start_col, end_col + 1)
            row_range_up = range(end_row, start_row - 1, -1)
            row_range_down = range(start_row, end_row + 1)
        elif direction == 'left-down':
            col_range = range(end_col, start_col - 1, -1)
            row_range_up = range(start_row, end_row + 1)
            row_range_down = range(end_row, start_row - 1, -1)
        elif direction == 'left-up':
            col_range = range(end_col, start_col - 1, -1)
            row_range_up = range(end_row, start_row - 1, -1)
            row_range_down = range(start_row, end_row + 1)

        for col in col_range:
            if down:
                for row in row_range_up:
                    if ws.cell(row=row, column=col).value not in [".", "4"]:
                        ws.cell(row=row, column=col).value = current_number
                        current_number += 1
                down = False
            else:
                for row in row_range_down:
                    if ws.cell(row=row, column=col).value not in [".", "4"]:
                        ws.cell(row=row, column=col).value = current_number
                        current_number += 1
                down = True
        return current_number

    # Determine the direction based on start position
    if start_position == 'upper-right':
        direction = 'right-down'
    elif start_position == 'lower-right':
        direction = 'right-up'
    elif start_position == 'upper-left':
        direction = 'left-down'
    elif start_position == 'lower-left':
        direction = 'left-up'
    elif start_position == 'top-left':
        direction = 'right-down'
    elif start_position == 'top-right':
        direction = 'left-down'
    elif start_position == 'bottom-left':
        direction = 'right-up'
    elif start_position == 'bottom-right':
        direction = 'left-up'
    else:
        raise ValueError("Invalid start position")

    # Apply zigzag numbering for the specified ranges
    current_number = 1
    for i in range(CZ + 1):
        current_number = apply_zigzag(6 + i * (B + 7), B + 5 + i * (B + 7), 1, A, current_number, direction)
        # Save the modified workbook
    wb.save(output_excel_path)


def zigzag_sum_XYZ(input_excel_path, output_excel_path, start_position):
    # Load the workbook and select the active worksheet
    wb = openpyxl.load_workbook(input_excel_path)
    ws = wb.active

    def apply_zigzag(start_row, end_row, start_col, end_col, current_number, direction):
        down = True

        if direction == 'right-down':
            col_range = range(start_col, end_col + 1)
            row_range_up = range(start_row, end_row + 1)
            row_range_down = range(end_row, start_row - 1, -1)
        elif direction == 'right-up':
            col_range = range(start_col, end_col + 1)
            row_range_up = range(end_row, start_row - 1, -1)
            row_range_down = range(start_row, end_row + 1)
        elif direction == 'left-down':
            col_range = range(end_col, start_col - 1, -1)
            row_range_up = range(start_row, end_row + 1)
            row_range_down = range(end_row, start_row - 1, -1)
        elif direction == 'left-up':
            col_range = range(end_col, start_col - 1, -1)
            row_range_up = range(end_row, start_row - 1, -1)
            row_range_down = range(start_row, end_row + 1)

        for col in col_range:
            if down:
                for row in row_range_up:
                    if ws.cell(row=row, column=col).value not in [".", "4"]:
                        ws.cell(row=row, column=col).value = current_number
                        current_number += 1
                down = False
            else:
                for row in row_range_down:
                    if ws.cell(row=row, column=col).value not in [".", "4"]:
                        ws.cell(row=row, column=col).value = current_number
                        current_number += 1
                down = True
        return current_number

    # Determine the direction based on start position
    if start_position == 'upper-right':
        direction = 'right-down'
    elif start_position == 'lower-right':
        direction = 'right-up'
    elif start_position == 'upper-left':
        direction = 'left-down'
    elif start_position == 'lower-left':
        direction = 'left-up'
    elif start_position == 'top-left':
        direction = 'right-down'
    elif start_position == 'top-right':
        direction = 'left-down'
    elif start_position == 'bottom-left':
        direction = 'right-up'
    elif start_position == 'bottom-right':
        direction = 'left-up'
    else:
        raise ValueError("Invalid start position")

    # Apply zigzag numbering for the specified ranges
    current_number = 1
    for i in range(WZ + 1):
        current_number = apply_zigzag(6 + i * (Y + 7), Y + 5 + i * (Y + 7), 1, X, current_number, direction)
        # Save the modified workbook
    wb.save(output_excel_path)

def multiple_lineup_ABC(input_excel_path1, input_excel_path2, input_excel_path3, output_excel_path):
    # Load the workbooks and select the active worksheets
    wb1 = openpyxl.load_workbook(input_excel_path1)
    wb2 = openpyxl.load_workbook(input_excel_path2)
    wb3 = openpyxl.load_workbook(input_excel_path3)
    ws1 = wb1.active
    ws2 = wb2.active
    ws3 = wb3.active
    # Create a new workbook for the output
    new_wb = openpyxl.Workbook()
    new_ws = new_wb.active

    # Variable to keep track of the row in the new worksheet
    new_row = 1

    # Iterate over the rows and columns in the input worksheets
    for row1, row2, row3 in zip(ws1.iter_rows(values_only=True), ws2.iter_rows(values_only=True), ws3.iter_rows(values_only=True)):
        for cell1, cell2, cell3 in zip(row1, row2, row3):
            # Write each cell value to the new worksheet in columns A to E
            new_ws.cell(row=new_row, column=1).value = new_row
            new_ws.cell(row=new_row, column=2).value = (1 + (new_row - 1) % A)
            new_ws.cell(row=new_row, column=3).value = 1 + int((new_row - 1) / A)
            new_ws.cell(row=new_row, column=4).value = 1 + (2 + int((new_row - 1) / A)) % (B + 7)
            new_ws.cell(row=new_row, column=5).value = cell1
            new_ws.cell(row=new_row, column=6).value = cell2
            new_ws.cell(row=new_row, column=7).value = cell3
            new_row += 1

    # Save the new workbook
    new_wb.save(output_excel_path)


def two_lineup_XYZ(input_excel_path1, input_excel_path2, output_excel_path):
    # Load the workbooks and select the active worksheets
    wb1 = openpyxl.load_workbook(input_excel_path1)
    wb2 = openpyxl.load_workbook(input_excel_path2)
    ws1 = wb1.active
    ws2 = wb2.active

    # Create a new workbook for the output
    new_wb = openpyxl.Workbook()
    new_ws = new_wb.active

    # Variable to keep track of the row in the new worksheet
    new_row = 1

    # Iterate over the rows and columns in the input worksheets
    for row1, row2 in zip(ws1.iter_rows(values_only=True), ws2.iter_rows(values_only=True)):
        for cell1, cell2 in zip(row1, row2):
            # Write each cell value to the new worksheet in columns A to E
            new_ws.cell(row=new_row, column=1).value = new_row
            new_ws.cell(row=new_row, column=2).value = (1 + (new_row - 1) % X)
            new_ws.cell(row=new_row, column=3).value = 1 + int((new_row - 1) / X)
            new_ws.cell(row=new_row, column=4).value = 1 + (2 + int((new_row - 1) / X)) % (Y + 7)
            new_ws.cell(row=new_row, column=5).value = cell1
            new_ws.cell(row=new_row, column=6).value = cell2
            new_row += 1

    # Save the new workbook
    new_wb.save(output_excel_path)


def column8_add_ABC(input_file, output_file):
    # Load the workbook and select the active worksheet
    wb = openpyxl.load_workbook(input_file)
    ws = wb.active

    # Determine the maximum row count
    max_row = ws.max_row

    # Iterate over each row to update column6
    for row in range(1, max_row + 1):
        column4_value = ws.cell(row=row, column=4).value
        column5_value = ws.cell(row=row, column=5).value
        column6_value = ws.cell(row=row, column=6).value

        # Initialize column6 value to 0
        column8_value = 0

        # Check the range of column3 value and set column6 accordingly
        if column4_value is not None and isinstance(column4_value, int):
            for i in range(CZ + 1):  # i ranges from 0 to 10
                if 7 + i * A < column4_value <= B + 7 + i * A:
                    if column5_value in [".", "4"]:
                        column8_value = 0
                    else:
                        column8_value = column6_value
                    break
            else:
                column8_value = 0
        # Set the value of column6 in the worksheet
        ws.cell(row=row, column=8).value = column8_value

    # Save the workbook with a new name or overwrite the original file
    wb.save(output_file)


def column7_add_XYZ(input_file, output_file):
    # Load the workbook and select the active worksheet
    wb = openpyxl.load_workbook(input_file)
    ws = wb.active

    # Determine the maximum row count
    max_row = ws.max_row

    # Iterate over each row to update column6
    for row in range(1, max_row + 1):
        column4_value = ws.cell(row=row, column=4).value
        column5_value = ws.cell(row=row, column=5).value
        column6_value = ws.cell(row=row, column=6).value

        # Initialize column6 value to 0
        column7_value = 0

        # Check the range of column3 value and set column6 accordingly
        if column4_value is not None and isinstance(column4_value, int):
            for i in range(WZ + 1):  # i ranges from 0 to 10
                if 7 + i * X < column4_value <= Y + 7 + i * X:
                    if column5_value in [".", "4"]:
                        column7_value = 0
                    else:
                        column7_value = column6_value
                    break
            else:
                column7_value = 0

        # Set the value of column6 in the worksheet
        ws.cell(row=row, column=7).value = column7_value

    # Save the workbook with a new name or overwrite the original file
    wb.save(output_file)

def sort_column7(input_file, output_file):
    # Load the workbook
    wb = openpyxl.load_workbook(input_file)
    ws = wb.active

    # Get all cells and their values
    all_cells = []
    for row in ws.iter_rows(values_only=True):
        all_cells.append(list(row))  # Convert tuple to list for mutability

    # Sort the rows by the 6th column (index 5, 0-based index)
    sorted_cells = sorted(all_cells, key=lambda x: x[6] if isinstance(x[6], (int, float)) else float('inf'))

    # Clear existing data in the worksheet
    for row in ws.iter_rows():
        for cell in row:
            cell.value = None

    # Write sorted data back to the worksheet
    for i, row_data in enumerate(sorted_cells, start=1):
        for j, value in enumerate(row_data, start=1):
            ws.cell(row=i, column=j, value=value)

    wb.save(output_file)

def sort_column8(input_file, output_file):
    # Load the workbook
    wb = openpyxl.load_workbook(input_file)
    ws = wb.active

    # Get all cells and their values
    all_cells = []
    for row in ws.iter_rows(values_only=True):
        all_cells.append(list(row))  # Convert tuple to list for mutability

    # Sort the rows by the 6th column (index 5, 0-based index)
    sorted_cells = sorted(all_cells, key=lambda x: x[7] if isinstance(x[7], (int, float)) else float('inf'))

    # Clear existing data in the worksheet
    for row in ws.iter_rows():
        for cell in row:
            cell.value = None

    # Write sorted data back to the worksheet
    for i, row_data in enumerate(sorted_cells, start=1):
        for j, value in enumerate(row_data, start=1):
            ws.cell(row=i, column=j, value=value)

    wb.save(output_file)


def select9_sort(input_file, output_file):
    # Load the workbook and select the active worksheet
    wb = openpyxl.load_workbook(input_file)
    ws = wb.active

    # Determine the maximum row count
    max_row = ws.max_row

    # Track the maximum value encountered so far for column7
    max_column8_value = 0

    # Iterate over each row to update column4 and column7
    for row in range(1, max_row + 1):
        column8_value = ws.cell(row=row, column=8).value
        column5_value = ws.cell(row=row, column=5).value
        column9_value = ws.cell(row=row, column=9).value

        # Check if column7_value is 0 or text
        if column8_value == 0 or isinstance(column8_value, str):
            ws.cell(row=row, column=9).value = 0
        else:
            # Update column4 based on the condition
            if column5_value == "1" or column5_value == 1:
                max_column8_value += 1
                ws.cell(row=row, column=9).value = max_column8_value
            else:
                ws.cell(row=row, column=9).value = 0

    # Save the workbook with a new name or overwrite the original file
    wb.save(output_file)

def resort_column9(input_file, output_file):
    # Load the workbook
    wb = openpyxl.load_workbook(input_file)
    ws = wb.active

    # Get all cells and their values
    all_cells = []
    for row in ws.iter_rows(values_only=True):
        all_cells.append(list(row))  # Convert tuple to list for mutability

    # Sort the rows by the 6th column (index 5, 0-based index)
    sorted_cells = sorted(all_cells, key=lambda x: x[8] if isinstance(x[8], (int, float)) else float('inf'))

    # Clear existing data in the worksheet
    for row in ws.iter_rows():
        for cell in row:
            cell.value = None

    # Write sorted data back to the worksheet
    for i, row_data in enumerate(sorted_cells, start=1):
        for j, value in enumerate(row_data, start=1):
            ws.cell(row=i, column=j, value=value)

    wb.save(output_file)

def sort_rmatch(input_file, result_file, sort_match_file):
    # 파일 불러오기
    max_resort = pd.read_excel(input_file, header=None)
    max_sort = pd.read_excel(result_file, header=None)

    # max 값 구하기
    max8 = max_resort.iloc[:, 7].max(skipna=True)
    max7 = max_sort.iloc[:, 6].max(skipna=True)

    # 낮은 값 비교
    max_match = min(max8, max7)

    # 8열에서 값이 1인 행의 인덱스
    insort8_col = max_resort[max_resort.iloc[:, 7] == 1].index[0]

    # 7열에서 값이 1인 행의 인덱스
    sort7_col = max_sort[max_sort.iloc[:, 6] == 1].index[0]

    # 8열이 없다면 추가
    if max_sort.shape[1] < 8:
        max_sort[7] = pd.NA

    # max_match 개수만큼 7열 값 복사 (범위 체크 추가)
    for i in range(max_match):
        if (insort8_col + i) < len(max_resort) and (sort7_col + i) < len(max_sort):
            max_sort.iloc[sort7_col + i, 7] = max_resort.iloc[insort8_col + i, 6]
        else:
            break

    # 8열이 비어있는 경우 5열 값으로 채우기
    for i in range(len(max_sort)):
        if pd.isna(max_sort.iloc[i, 7]):
            if i >= max_match:
                max_sort.iloc[i, 7] = "."
            else:
                max_sort.iloc[i, 7] = max_sort.iloc[i, 4]

    # 결과 저장
    max_sort.to_excel(sort_match_file, index=False, header=False)

def line_rwafermap(input_file, output_file):
    # Load the workbook and select the active worksheet
    wb = openpyxl.load_workbook(input_file)
    ws = wb.active

    # Create a new workbook for the output
    new_wb = openpyxl.Workbook()
    new_ws = new_wb.active

    # Iterate over each row to write column4_value to the specified cell
    for row in range(1, ws.max_row + 1):
        column2_value = ws.cell(row=row, column=2).value
        column3_value = ws.cell(row=row, column=3).value
        column4_value = ws.cell(row=row, column=8).value

        # Convert column2_value and column3_value to 1-based index
        column_index = column2_value  # Assuming column2_value is already 1-based
        row_index = column3_value  # Adding 1 because row values are 0-based

        # Write column4_value to the specified cell in the new worksheet
        new_ws.cell(row=row_index, column=column_index, value=column4_value)

    # Save the new workbook with the specified output file name
    new_wb.save(output_file)


def excel_asc_map(input_excel_path, output_asc_path):
    # Load the workbook and select the active worksheet
    wb = openpyxl.load_workbook(input_excel_path)
    ws = wb.active

    with open(output_asc_path, 'w', encoding='utf-8') as file:
        for row in ws.iter_rows(values_only=True):
            line = ''.join([str(cell) if cell is not None else ' ' for cell in row])
            file.write(line + '\n')


def result_map_file(file_path):
    try:
        if not file_path:
            print("No file selected. Exiting.")
            return

        print("result_map_file try 진입")
        map_file = r'C:\\wafer\\rmap\\VISION01S_map.ASC'  # 원본 파일 경로
        selected_file = os.path.basename(file_path)  # 파일 경로에서 파일 이름 추출
        result_map_file_path = os.path.join(os.path.dirname(file_path),
                                            f"{selected_file.replace('.ASC', '')}S_map.ASC")  # 새로 생성될 파일 경로
        print(f"result_map_file : {result_map_file_path}")

        # 파일 이름 변경
        os.rename(map_file, result_map_file_path)

        print(f"Renamed {map_file} to {result_map_file_path}")
        return result_map_file_path

    except FileNotFoundError:
        print(f"File not found error: {map_file}")
    except Exception as e:
        print(f"Failed to rename map file: {e}")

def run_recon_map():

    print("Recon map function running...")


def file_delete():
    # 삭제할 파일들의 경로 리스트
    file_paths = [
        r"C:\wafer\rmap\VISION01.ASC",
        r"C:\wafer\rmap\VISION01.xlsx",
        r"C:\wafer\rmap\VISION01_sum.xlsx",
        r"C:\wafer\rmap\VISION01A.ASC",
        r"C:\wafer\rmap\VISION01A.xlsx",
        r"C:\wafer\rmap\VISION01S.ASC",
        r"C:\wafer\rmap\VISION01S.xlsx",
        r"C:\wafer\rmap\VISION01S_sum.xlsx",
        r"C:\wafer\rmap\VISION01_mla.xlsx",
        r"C:\wafer\rmap\VISION01S_ml.xlsx",
        r"C:\wafer\rmap\VISION01_8ad.xlsx",
        r"C:\wafer\rmap\VISION01S_7ad.xlsx",
        r"C:\wafer\rmap\VISION01_sort.xlsx",
        r"C:\wafer\rmap\VISION01_qual.xlsx",
        r"C:\wafer\rmap\VISION01S_sort.xlsx",
        r"C:\wafer\rmap\VISION01_resort.xlsx",
        r"C:\wafer\rmap\VISION01S_rmatch.xlsx",
        r"C:\wafer\rmap\VISION01S_map.xlsx"
    ]

    for file_path in file_paths:
        if os.path.exists(file_path):
            os.remove(file_path)
            print(f"{file_path} 파일이 성공적으로 삭제되었습니다.")
        else:
            print(f"{file_path} 파일을 찾을 수 없습니다.")


if __name__ == "__main__":
    run_recon_map()

    file_path = select_file()
    if file_path:
        copy_files(file_path)

    file_path1 = 'C:\\wafer\\rmap\\VISION01.ASC'
    wafermap_x_y(file_path1)
    file_path2 = 'C:\\wafer\\rmap\\VISION01S.ASC'
    wafermap_x_y(file_path2)

    A, B = wafermap_x_y(file_path1)
    CZ = int(count_rows(file_path1) / (B + 7))
    X, Y = wafermap_x_y(file_path2)
    WZ = int(count_rows(file_path2) / (Y + 7))
    print(f"A={A}, B={B}, CZ={CZ}, X={X},Y={Y}, WZ={CZ}")

    file_path1 = r'C:\wafer\rmap\VISION01.ASC'
    wafermap_x_y(file_path1)
    file_path2 = r'C:\wafer\rmap\VISION01S.ASC'
    wafermap_x_y(file_path2)

    file_path1 = r'C:\wafer\rmap\VISION01.ASC'
    count_rows(file_path1)
    print(f"row1 : {count_rows(file_path1)}")
    file_path2 = r'C:\wafer\rmap\VISION01S.ASC'
    count_rows(file_path2)
    print(f"row2 : {count_rows(file_path2)}")

    A, B = wafermap_x_y(file_path1)
    CZ = int(count_rows(file_path1)/(B+7))
    X, Y = wafermap_x_y(file_path2)
    WZ = int(count_rows(file_path2)/(Y+7))

    input_file = r'C:\wafer\rmap\VISION01.ASC'
    output_file = r'C:\wafer\rmap\VISION01.xlsx'
    asc_excel_map(input_file, output_file)

    input_file = r'C:\wafer\rmap\VISION01A.ASC'
    output_file = r'C:\wafer\rmap\VISION01A.xlsx'
    asc_excel_map(input_file, output_file)

    input_file = r'C:\wafer\rmap\VISION01S.ASC'
    output_file = r'C:\wafer\rmap\VISION01S.xlsx'
    asc_excel_map(input_file, output_file)

    input_file = r'C:\wafer\rmap\VISION01.xlsx'
    output_file = r'C:\wafer\rmap\VISION01_sum.xlsx'
    start_position = 'top-right'  # 'upper-right', 'lower-right', 'upper-left', 'lower-left', 'top-left', 'top-right', 'bottom-left', 'bottom-right'
    zigzag_sum_ABC(input_file, output_file, start_position)

    input_file = r'C:\wafer\rmap\VISION01S.xlsx'
    output_file = r'C:\wafer\rmap\VISION01S_sum.xlsx'
    start_position = 'top-left'
    zigzag_sum_XYZ(input_file, output_file, start_position)

    input_file1 = r'C:\wafer\rmap\VISION01.xlsx'
    input_file2 = r'C:\wafer\rmap\VISION01_sum.xlsx'
    input_file3 = r'C:\wafer\rmap\VISION01A.xlsx'
    output_file = r'C:\wafer\rmap\VISION01_mla.xlsx'
    multiple_lineup_ABC(input_file1, input_file2, input_file3, output_file)

    input_file1 = r'C:\wafer\rmap\VISION01S.xlsx'
    input_file2 = r'C:\wafer\rmap\VISION01S_sum.xlsx'
    output_file = r'C:\wafer\rmap\VISION01S_ml.xlsx'
    two_lineup_XYZ(input_file1, input_file2, output_file)

    input_file = r'C:\wafer\rmap\VISION01_mla.xlsx'
    output_file = r'C:\wafer\rmap\VISION01_8ad.xlsx'
    column8_add_ABC(input_file, output_file)

    input_file = r'C:\wafer\rmap\VISION01S_ml.xlsx'
    output_file = r'C:\wafer\rmap\VISION01S_7ad.xlsx'
    column7_add_XYZ(input_file, output_file)

    input_file = r'C:\wafer\rmap\VISION01_8ad.xlsx'
    output_file = r'C:\wafer\rmap\VISION01_sort.xlsx'
    sort_column8(input_file, output_file)

    input_file = r'C:\wafer\rmap\VISION01S_7ad.xlsx'
    output_file = r'C:\wafer\rmap\VISION01S_sort.xlsx'
    sort_column7(input_file, output_file)

    input_file = r'C:\wafer\rmap\VISION01_sort.xlsx'
    output_file = r'C:\wafer\rmap\VISION01_qual.xlsx'
    select9_sort(input_file, output_file)

    input_file = r'C:\wafer\rmap\VISION01_qual.xlsx'
    output_file = r'C:\wafer\rmap\VISION01_resort.xlsx'
    resort_column9(input_file, output_file)

    input_file = r'C:\wafer\rmap\VISION01_resort.xlsx'
    result_file = r'C:\wafer\rmap\VISION01S_sort.xlsx'
    sort_match_file = r'C:\wafer\rmap\VISION01S_rmatch.xlsx'
    sort_rmatch(input_file, result_file, sort_match_file)

    input_file = r'C:\wafer\rmap\VISION01S_rmatch.xlsx'
    output_file = r'C:\wafer\rmap\VISION01S_map.xlsx'
    line_rwafermap(input_file, output_file)

    input_file = r'C:\wafer\rmap\VISION01S_map.xlsx'
    output_file = r'C:\wafer\rmap\VISION01S_map.ASC'
    excel_asc_map(input_file, output_file)

    file_path = select_file()  # 파일 선택 함수 호출
    if file_path:
        result_map_file(file_path)  # 파일 이름 변경 함수 호출

    file_delete()