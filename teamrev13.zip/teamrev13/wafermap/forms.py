from django import forms

class InverseMapForm(forms.Form):
    # 필요한 필드를 정의합니다.
    pass

class ReconMapForm(forms.Form):
    # 필요한 필드를 정의합니다.
    pass

class ConversionMapForm(forms.Form):
    # 필요한 필드를 정의합니다.
    pass
