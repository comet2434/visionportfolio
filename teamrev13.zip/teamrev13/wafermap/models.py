from django.db import models
from django.contrib.auth.models import User
from users.models import CustomUser
class UploadedFile(models.Model):
    asc_file = models.FileField(upload_to='uploads/')
    additional_file = models.FileField(upload_to='uploads/', blank=True, null=True)
    start_position = models.CharField(max_length=20)
    uploaded_at = models.DateTimeField(auto_now_add=True)
    processed_at = models.DateTimeField(blank=True, null=True)
    result_file = models.FileField(upload_to='results/', blank=True, null=True)
    user = models.ForeignKey(CustomUser, on_delete=models.CASCADE, related_name='wafermap')

    class Meta:
        db_table = 'wafermap'

    def __str__(self):
        return f"File uploaded at {self.uploaded_at}"

