from django.urls import path
from . import views

app_name = 'wafermap'

urlpatterns = [
    path('conversionmap/', views.conversion_map, name='conversion_map'),
    path('inversemap/', views.inverse_map, name='inverse_map'),
    path('reconmap/', views.recon_map, name='recon_map'),
]
