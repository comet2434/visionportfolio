import tensorflow as tf
from tensorflow.keras import layers, models
from tensorflow.keras.utils import to_categorical

def train_with_varied_epochs(x_train, y_train, x_test, y_test, min_epochs=5, max_epochs=50, step=5):
    train_accuracies = []
    test_accuracies = []

    for epochs in range(min_epochs, max_epochs+1, step):
        model = models.Sequential([
            layers.Flatten(input_shape=(28, 28)),
            layers.Dense(128, activation='relu'),
            layers.Dropout(0.2),
            layers.Dense(10, activation='softmax')
        ])

        model.compile(optimizer='adam',
                      loss='categorical_crossentropy',
                      metrics=['accuracy'])

        model.fit(x_train, y_train, epochs=epochs, verbose=0)
        _, train_accuracy = model.evaluate(x_train, y_train, verbose=0)
        _, test_accuracy = model.evaluate(x_test, y_test, verbose=0)

        train_accuracies.append(train_accuracy)
        test_accuracies.append(test_accuracy)

        print(f'Epochs: {epochs}, Training Accuracy: {train_accuracy}, Test Accuracy: {test_accuracy}')

    return train_accuracies, test_accuracies

# 예제 사용
(x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()
x_train = x_train / 255.0
x_test = x_test / 255.0

y_train = to_categorical(y_train)
y_test = to_categorical(y_test)


train_accuracies, test_accuracies = train_with_varied_epochs(x_train, y_train, x_test, y_test)
