import matplotlib.pyplot as plt
import numpy as np
import tensorflow as tf
from tensorflow.keras.datasets import mnist
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten,Dropout
from tensorflow.keras.utils import to_categorical
import matplotlib.font_manager as fm
from tensorflow.keras import layers, models

def set_korean_font():
    #path = "c:/Windows/Fonts/malgun.ttf" # 윈도우의 경우
    #font_prop = fm.FontProperties(fname=path)
    #plt.rc('font', family=font_prop.get_name())
    plt.rcParams['font.family'] = 'Malgun Gothic'  # 맑은 고딕

# 시각화 함수 정의
# 예측한 이미지와 실제 레이블을 시각화합니다.
# 예측이 맞으면 파란색, 틀리면 빨간색 레이블을 표시합니다.
def plot_image(predictions_array, true_label, img):
    predictions_array, true_label, img = predictions_array, true_label, img
    plt.grid(False)
    plt.xticks([])
    plt.yticks([])
    plt.imshow(img, cmap=plt.cm.binary)

    predicted_label = np.argmax(predictions_array)
    if predicted_label == true_label:
        color = 'blue'
    else:
        color = 'red'

    plt.xlabel(f"{predicted_label} ({100 * np.max(predictions_array):2.0f}%) ({true_label})",
               color=color)

# 각 클래스에 대한 예측 확률을 막대 그래프로 표시합니다.
# 정답인 클래스는 파란색, 모델이 예측한 클래스는 빨간색으로 표시합니다.
def plot_value_array(predictions_array, true_label):
    predictions_array, true_label = predictions_array, true_label
    plt.grid(False)
    plt.xticks(range(10))
    plt.yticks([])
    thisplot = plt.bar(range(10), predictions_array, color="#777777")
    plt.ylim([0, 1])
    predicted_label = np.argmax(predictions_array)

    thisplot[predicted_label].set_color('red')
    thisplot[true_label].set_color('blue')

#if __name__ == '__main__()':
# 그래프(plt)에 한글 세팅
set_korean_font()
# 훈련횟수 입력
epoch = int(input('input epoch(훈련횟수): '))
# MNIST 데이터셋 로드
(x_train, y_train), (x_test, y_test) = mnist.load_data()
# #0과 1로 정규화
x_train, x_test = x_train / 255.0, x_test / 255.0
# 훈련셋의 레이블(정답)값을 one-hot코드로 변환
# 이렇게 변환하면 컴파일시 loss='categorical_crossentropy'를 사용해야함.
# 그렇치 않으면 컴파일시 loss=sparse_categorical_crossentropy를 사용함(73번라인)
y_train = to_categorical(y_train)

# 검사셋의 레이블(정답)값을 one-hot코드로 변환
y_test = to_categorical(y_test)

# 모델 정의

model = models.Sequential([
    # layers의 함수로 이는 이미지를 1차원으로 평평하게 만들어주는 역할
    Flatten(input_shape=(28, 28)),  # 입력 레이어: 28x28(748) 픽셀 이미지를 1차원 배열로 변환
    Dense(128, activation='relu'),  # 은닉 레이어: 128개의 뉴런, ReLU 활성화 함수
    Dropout(0.2),# 드롭아웃 레이어: 20%의 드롭아웃 비율을 적용하여 과적합을 방지하기 위해 뉴런을 랜덤하게 비활성화
    Dense(64, activation='relu'),  # 새로운 은닉층 추가,
    Dense(10, activation='softmax') # 출력 레이어: 10개의 뉴런을 가진 출력 레이어를 추가하고 활성화 함수로 softmax를 사용하여 10가지 클래스에 대한 확률 분포를 출력
])
'''
은닉층을 추가하는 것은 신경망의 복잡성을 높이고 모델이 더 다양한 특징과 패턴을 
학습할 수 있도록 도움. 은닉층은 입력 데이터의 비선형성을 캡처하고 다양한 
특징 간의 상호작용을 학습하는 데 도움을 줌.
단순히 epoch(에폭) 수를 늘리는 것과 은닉층을 추가하는 것은 서로 다른 개념임. 
에폭 수를 늘리는 것은 주어진 데이터셋에 대해 모델이 더 많은 학습을 할 수 있도록 
하는 것이며, 모델이 데이터셋을 더 잘 학습할 수 있도록 도와줌. 
반면에 은닉층 추가는 모델의 구조 자체를 변경하여 더 많은 복잡한 관계를 학습할 
수 있도록 도움.
'''

model.compile(optimizer='adam',##Adam은 최적화 알고리즘으로, 훈련 데이터를 기반으로 네트워크 가중치를 반복적으로 업데이트하는 데 사용됨. 이는 AdaGrad와 RMSProp 두 확장된 확률적 경사 하강법의 이점을 결합한 것
              # 희소 범주형 크로스엔트로피는 (loss='sparse_categorical_crossentropy')목표 레이블이 정수인 경우에 일반적으로 사용되며, 원-핫 인코딩 벡터가 아닌 경우 사용
              loss='categorical_crossentropy',# 범주형 크로스엔트로피는 목표 레이블이 정수이고 원-핫 인코딩 벡터인 경우 사용
              metrics=['accuracy'])# 이 매개변수는 모델의 성능을 평가하는 데 사용되는 지표를 지정. 이 경우 정확도 지표가 선택되어, 정확하게 예측된 클래스의 비율을 계산함

'''
모델 훈련 하고 훈련결과 history사전 확보
1. Forward Propagation (순전파): 입력데이타를 모델에 통과  
  각층에서 가중치(weight)를 적용하고
  활성화 함수(activation function)를 통해 결과 값을 계산
2. Loss 계산 : 계산된 출력과 실제 출력(y_train)을 비교하여 손실 함수(loss function, 
   예: Mean Squared Error, Cross-Entropy 등)를 통해 오차(loss)를 계산함. 
3. Backward Propagation (역전파): 손실 값을 줄이기 위해 가중치를 업데이트. 
   이를 위해 손실 함수의 기울기(gradient)를 계산하고
   옵티마이저(optimizer, 예: SGD, Adam 등)를 사용하여 가중치를 업데이트함. 
4. Epoch 반복: 이 과정이 하나의 에폭(epoch) 동안 수행되고, 여러 에폭에 걸쳐 반복.
5. 검증 데이타로 테스트 셋을 사용했다.
6. 주의: 아래와 같이 model.fit(x_train, y_train, epochs=5)와 같이 validation_data를
   지정하지 않으면, 모델은 훈련 중에 따로 검증 데이터셋을 활용하여 성능을 평가하지 않고, 
   단순히 훈련 데이터셋으로만 모델을 학습하게 됩니다. 이 경우에는 각 에포크(epoch)마다 
   훈련 데이터셋에 대한 성능 지표(정확도, 손실 등)가 출력되지만, 이 모델이 다른 데이터셋에서 
   얼마나 잘 일반화되는지를 평가할 수 있는 지표는 제공되지 않습니다. 
   그래서 아래 fit함수의 파라미터로 일반적으로 validation_data=(x_test, y_test)을 추가하여 사용
'''
history = model.fit(x_train, y_train, epochs=epoch, validation_data=(x_test, y_test))

'''
모델 평가 
1. Forward Propagation (순전파): 평가 데이터(x_test)를 모델에 입력하여 
   예측 값을 계산.
2. Loss 계산: 예측 값과 실제 값(y_test)을 비교하여 손실 함수를 통해 오차를 
   계산.
3. 평가 지표 계산: 정확도(accuracy), 손실 값(loss) 등 모델의 성능을 나타내는
   다양한 지표를 계산. evaluate 함수는 손실 값과 사용자 정의한 다른 지표들을 
   반환.
'''
test_loss, test_acc = model.evaluate(x_test, y_test)
print(f'\n모델 평가 결과 ==> 테스트 정확도: {test_acc}')


# 예측 예제 시각화##################
# 예측결과 가져오기
# 모델이 테스트 데이터(x_test)에 대한 예측 값을 생성
# predictions 는 각 테스트 샘플에 대한 클래스 확률을 포함하는 배열.
predictions = model.predict(x_test)
print("Predictions for the first 5 test samples:\n", predictions[:5])

num_rows = 5 # 시각화할 챠트의 행수
num_cols = 3 # 시각화할 챠트의 열수
num_images = num_rows * num_cols # 시각화할 이미지 총 개수(5*3 = 15개)
# 시각화될 전체 Figure 크기를 설정합니다. figsize 파라미터는 (폭, 높이) 형식입니다.
# 여기서는 (폭12, 높이10)의 크기로 설정
plt.figure(figsize=(2 * 2 * num_cols, 2 * num_rows))

# 예측결과의 시각화
for i in range(num_images): #0~14
    # 첫번째 서브플롯 설정
    plt.subplot(num_rows, 2 * num_cols, 2 * i + 1) #1,3,5,7,9,...;이미지

    # 이미지 시각화
    # 다음 함수는 예측된 값(predictions[i]), 실제 값(np.argmax(y_test[i])), 이미지(x_test[i])를
    # 인자로 받아 이미지를 시각화
    # np.argmax(y_test[i])를 통해 실제 레이블도 One-Hot 인코딩된 값을 클래스 인덱스로 변환
    plot_image(predictions[i], np.argmax(y_test[i]), x_test[i])

    # 두번째 서브플롯 설정
    plt.subplot(num_rows, 2 * num_cols, 2 * i + 2) #2,4,6,8,10,....;막대그래프

    # 값 막대그래프 시각화
    # np.argmax(y_test[i]) ~ 배열에서 가장 큰 값의 인덱스를 반환하는 NumPy 함수
    # 여기서는 One-hot 인코딩은 범주형 데이터를 1의 위치인덱스로 숫자적의미로 해석
    plot_value_array(predictions[i], np.argmax(y_test[i]))

######### 레이아웃 조정 및 출력
plt.tight_layout() # 서브플롯 간의 간격을 자동으로 조정하여 레이아웃을 깔끔하게 만듦.
plt.show() # 최종적으로 설정된 그래프를 화면에 출력

# 에포크에 따른 정확도 및 손실 그래프
plt.figure(figsize=(12, 6))

# 훈련 및 검증 손실
plt.subplot(1, 2, 1)
# history.history['loss']는 모델을 훈련할 때 발생한 손실값(loss)들이 저장된 딕셔너리에서 'loss' 키에 해당하는 값들을 나타냄.
plt.plot(history.history['loss'], label='훈련셋 손실')
plt.plot(history.history['val_loss'], label='검증셋 손실')
plt.xlabel('훈련횟수') # epoch
plt.ylabel('손실')
plt.title('훈련과 검증셋 손실')
plt.legend()

# 훈련 및 검증 정확도
plt.subplot(1, 2, 2)
plt.plot(history.history['accuracy'], label='훈련셋 정확도')
plt.plot(history.history['val_accuracy'], label='검증셋 정확도')
plt.xlabel('훈련횟수')
plt.ylabel('정확도')
plt.title('훈련과 검증셋 정확도')
plt.legend()

plt.tight_layout()
plt.show()
######################  모델 저장 ##########
# HDF5 파일 형식 대신 네이티브 Keras 형식을 사용하는 것이 권장된다.
model.save('mnist_model.keras')
# keras.saving.save_model(model, 'mnist_model.keras')
print('모델이 저장되었습니다.')


'''
1875/1875,  313/313 의 의미 ===> 훈련데이타,검증데이타를 각각 32개씩 묶어
처리하면 60000/32 = 1875 이며  10000/32 = 312.5 이다. 
32개씩 묶어 내부적으로 처리하는 이유는 효율적 기계학습을 위한 메모리등 고려사항이다.
이는 상당히 기술적이 판단을 요하는 하이퍼파라미터 이다. 
이러한 하이퍼 파라미터의 종류는 기계학습에서 다음과 같은 것들이 있다.

학습률(learning rate): 경사하강법에서 가중치를 업데이트할 때 사용되는 
비율을 제어합니다.

배치 크기(batch size): 한 번에 모델에 공급되는 학습 데이터의 샘플 수를 
결정합니다.

에포크 수(epochs): 전체 훈련 데이터셋을 사용하여 모델을 여러 번 반복적으로 
학습시키는 횟수를 지정합니다.

은닉층의 유닛 수(뉴런 개수): 신경망의 각 층에 있는 뉴런의 개수를 결정합니다.

활성화 함수(activation function): 각 층의 출력을 계산하는 방법을 결정하는 
함수입니다.
'''


'''
위 함수 2개에 대한 해설 
plot_image(predictions_array, true_label, img): 

입력: predictions_array는 모델의 각 클래스에 대한 예측 확률 배열, true_label는 실제 레이블(정답), img는 이미지 데이터.
기능: 이 함수는 주어진 이미지(img)를 시각화하고, 모델이 예측한 레이블과 실제 레이블의 일치 여부에 따라 색상이 다른 레이블을 표시합니다.
동작:
주어진 이미지(img)를 이진색으로 표시하고, 해당 이미지에 대한 모델의 예측 결과(predictions_array)를 확인합니다.
모델이 예측한 레이블과 실제 레이블을 비교하여, 예측이 맞으면 파란색으로, 틀리면 빨간색으로 레이블을 표시합니다.
예측 레이블과 예측 확률 및 실제 레이블을 축에 표시합니다.
plot_value_array(predictions_array, true_label): 

입력: predictions_array는 모델의 각 클래스에 대한 예측 확률 배열, true_label는 실제 레이블(정답).
기능: 이 함수는 예측한 각 클래스의 확률을 막대 그래프로 시각화합니다. 정답 레이블은 파란색으로, 모델이 예측한 클래스는 빨간색으로 표시됩니다.
동작:
각 클래스에 대한 예측 확률 배열을 그래프로 표시하고, 정답 레이블과 모델이 예측한 레이블을 시각적으로 대조할 수 있습니다.
그래프 내에서 정답 레이블은 파란색으로, 모델이 예측한 레이블은 빨간색으로 표시되며, 길이로 확률을 나타냅니다.
'''