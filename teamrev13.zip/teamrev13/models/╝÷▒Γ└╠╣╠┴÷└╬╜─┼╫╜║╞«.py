import tensorflow as tf
import numpy as np
import matplotlib.pyplot as plt
from PIL import Image
# Load the saved model
model = tf.keras.models.load_model('mnist_model.keras')

# Define a function to preprocess the input image
def preprocess_image(image):
    # Convert the image to grayscale
    image = image.convert("L")
    image = Image.eval(image, lambda x: 255-x) # 반전
    # Resize the image to 28x28 pixels
    image = image.resize((28, 28))
    # 픽셀 값이 128 미만인 경우 255(흰색)로, 그렇지 않으면 0(검은색)으로 설정
    #image = Image.eval(image, lambda x: 255 if x < 200 else 0)

    # Normalize pixel values to [0, 1]
    image_array = np.array(image) / 255.0

    # Add a new axis for model compatibility
    input_image = np.expand_dims(image_array, axis=0)

    return input_image


# Load and preprocess the input image
image = Image.open("../images/333.jpg")
input_image = preprocess_image(image) # 28*28 사이즈로 전처리

# Perform prediction
prediction = model.predict(input_image)
predicted_digit = np.argmax(prediction)
confidence_score = np.max(prediction) * 100

# Display the prediction
print(f"Predicted digit: {predicted_digit} with confidence: {confidence_score:.2f}%")

# Visualize the prediction
plt.figure()
plt.imshow(input_image[0], cmap=plt.cm.binary)  # Display the preprocessed image
plt.xlabel(f"Predicted digit: {predicted_digit} with confidence: {confidence_score:.2f}%", color='blue')
plt.show()